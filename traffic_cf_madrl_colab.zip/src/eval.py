"""
Evaluation entry for CF-MADRL.
Runs simulation and generates plots internally.
"""

import os
import json

from src.agent_manager import AgentManager
from src.multi_agent_sumo_env import MultiAgentSumoEnv
from tools.visualize import plot_evaluation
from tools.utils import ensure_dir, Logger, scan_topology


def evaluate_rl(config):

    Logger.header("CF-MADRL Evaluation")

    sim_steps = 100_000
    junction_ids = config["system"]["controlled_junctions"]

    # ---- Discover topology ----
    max_lanes, max_phases = scan_topology(config)

    # ---- Build environment ----
    env = MultiAgentSumoEnv(
        {
            "config": config,
            "junction_ids": junction_ids,
            "max_lanes": max_lanes,
            "max_phases": max_phases,
            "max_steps": sim_steps,
            "evaluation_mode": True,
        }
    )

    # ---- Load agents ----
    agent_manager = AgentManager(env, config, junction_ids)

    checkpoint_dir = os.path.abspath(config["system"]["model_save_path"])

    if os.path.exists(checkpoint_dir):
        agent_manager.load(checkpoint_dir)
        Logger.success("Checkpoint loaded.")
    else:
        Logger.warning("No checkpoint found. Using random policies.")
        agent_manager.build()

    # ---- Run simulation ----
    obs, _ = env.reset()

    metrics = {aid: {"rewards": [], "queues": [], "waits": []} for aid in junction_ids}

    done = False
    step = 0
    clearance_time = 0

    while step < sim_steps and not done:
        actions = {}

        for aid in junction_ids:
            policy = agent_manager.algo.get_policy(aid)
            action, _, _ = policy.compute_single_action(
                obs[aid],
                explore=False,  # Deterministic evaluation
            )
            actions[aid] = action

        obs, rewards, dones, truncs, infos = env.step(actions)

        for aid in junction_ids:
            metrics[aid]["rewards"].append(rewards[aid])
            metrics[aid]["queues"].append(infos[aid].get("step_queue", 0))
            metrics[aid]["waits"].append(infos[aid].get("step_wait", 0))

        step += 1
        done = any(dones.values()) or all(truncs.values())

        if done:
            clearance_time = env.steps_counter * config["sumo"]["step_length"]

    agent_manager.close()
    env.close()

    # ---- Save logs ----
    ensure_dir("logs")

    log_data = {
        "madrl": metrics,
        "clearance_time": clearance_time,
    }

    log_path = "logs/evaluation_logs.json"

    with open(log_path, "w") as f:
        json.dump(log_data, f)

    Logger.success("Evaluation completed.")
    Logger.info(f"Clearance Time: {clearance_time:.2f}s")

    # ---- Plot inside evaluation ----
    try:
        plot_evaluation(
            log_file=log_path,
            output_dir="plots",
        )
        Logger.success("Plots generated successfully.")
    except Exception as e:
        Logger.warning(f"Plotting failed: {e}")

    return {
        "metrics": metrics,
        "clearance_time": clearance_time,
    }
